package config

type Excel struct {
	Dir string `mapstructure:"dir" json:"dir" yaml:"dir"`
}
